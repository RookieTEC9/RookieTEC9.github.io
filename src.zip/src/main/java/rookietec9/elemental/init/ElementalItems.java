package rookietec9.elemental.init;

import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.model.ModelResourceLocation;
import net.minecraft.item.Item;
import net.minecraftforge.fml.common.registry.GameRegistry;
import rookietec9.elemental.Reference;
import net.minecraftforge.fml.common.registry.GameRegistry;

public class ElementalItems {
	public static Item fire_shard;
	
    public static void init() {
    	fire_shard = new Item().setUnlocalizedName("fire_shard");
    }
    public static void register() {
    	GameRegistry.registerItem(fire_shard, fire_shard.getUnlocalizedName().substring(5)); //tile."fire_sword"
    
    } 
    public static void registerRenders() {
    	registerRender(fire_shard);
    }
    public static void registerRender(Item item) {
    Minecraft.getMinecraft().getRenderItem().getItemModelMesher().register(item, 0, new ModelResourceLocation(Reference.MOD_ID + ":" + item.getUnlocalizedName().substring(5), "inventory" ));	
    }
    } 

