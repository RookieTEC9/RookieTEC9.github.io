package rookietec9.elemental.proxy;

import rookietec9.elemental.init.ElementalItems;

public class ClientProxy extends CommonProxy {
	@Override   
	public void registerRenders() {
		ElementalItems.registerRenders();
	   }
}