package rookietec9.elemental.proxy;

public class CommonProxy {
   public void registerRenders() {
	   
   }
}
