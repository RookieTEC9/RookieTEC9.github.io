package rookietec9.elemental;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import rookietec9.elemental.init.ElementalItems;
import rookietec9.elemental.proxy.CommonProxy;


@Mod(modid= Reference.MOD_ID , name = Reference.MOD_NAME , version = Reference.VERSION )
public class ModTut {
	
	@SidedProxy(clientSide = Reference.CLIENT_PROXY_CLASS , serverSide = Reference.SERVER_PROXY_CLASS)
	public static CommonProxy proxy;
	
	
	@EventHandler
    public void preInit(FMLPreInitializationEvent Event) { 
		ElementalItems.init();
		ElementalItems.register();
	}
	@EventHandler
    public void init(FMLInitializationEvent Event) { 
		proxy.registerRenders();
	}
	@EventHandler
    public void postInit(FMLPostInitializationEvent Event) { }
}
